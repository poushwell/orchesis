"""Rule evaluation engine."""

from typing import Any

from orchesis.models import Decision


def _get_path(request: dict[str, Any]) -> str | None:
    params = request.get("params")
    if not isinstance(params, dict):
        return None
    path = params.get("path")
    return path if isinstance(path, str) else None


def _get_query_operation(request: dict[str, Any]) -> str | None:
    params = request.get("params")
    if not isinstance(params, dict):
        return None
    query = params.get("query")
    if not isinstance(query, str):
        return None
    parts = query.strip().split()
    if not parts:
        return None
    return parts[0].upper()


def evaluate(request: dict[str, Any], policy: dict[str, Any]) -> Decision:
    """Evaluate request against policy rules."""
    reasons: list[str] = []
    rules_checked: list[str] = []

    rules = policy.get("rules")
    if not isinstance(rules, list):
        return Decision(allowed=True, reasons=reasons, rules_checked=rules_checked)

    for rule in rules:
        if not isinstance(rule, dict):
            continue

        rule_name = rule.get("name")
        if not isinstance(rule_name, str):
            continue

        if rule_name == "budget_limit":
            max_cost = rule.get("max_cost_per_call")
            cost = request.get("cost")
            if isinstance(max_cost, int | float) and isinstance(cost, int | float):
                rules_checked.append("budget_limit")
                if cost > max_cost:
                    reasons.append(
                        f"budget_limit: cost {cost} exceeds max_cost_per_call {max_cost}"
                    )

        elif rule_name == "file_access":
            path = _get_path(request)
            if path is None:
                continue

            rules_checked.append("file_access")

            denied_paths = rule.get("denied_paths")
            if isinstance(denied_paths, list):
                for denied_path in denied_paths:
                    if isinstance(denied_path, str) and path.startswith(denied_path):
                        reasons.append(
                            f"file_access: path '{path}' is denied by '{denied_path}'"
                        )
                        break

            allowed_paths = rule.get("allowed_paths")
            if isinstance(allowed_paths, list) and allowed_paths:
                allowed_match = any(
                    isinstance(allowed_path, str) and path.startswith(allowed_path)
                    for allowed_path in allowed_paths
                )
                if not allowed_match:
                    reasons.append(f"file_access: path '{path}' is outside allowed_paths")

        elif rule_name == "sql_restriction":
            operation = _get_query_operation(request)
            if operation is None:
                continue

            rules_checked.append("sql_restriction")
            denied_operations = rule.get("denied_operations")
            if isinstance(denied_operations, list):
                denied_upper = {
                    op.upper() for op in denied_operations if isinstance(op, str)
                }
                if operation in denied_upper:
                    reasons.append(f"sql_restriction: {operation} is denied")

        elif rule_name == "rate_limit":
            rules_checked.append("rate_limit:not_evaluated")

        else:
            rules_checked.append(f"unknown_rule:{rule_name}:skipped")

    return Decision(
        allowed=len(reasons) == 0,
        reasons=reasons,
        rules_checked=rules_checked,
    )
